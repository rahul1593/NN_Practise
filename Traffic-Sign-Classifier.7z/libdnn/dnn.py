#
# @Description  : This file contains wrapper functions for implementation of neural network components 
#				  implemented in dnn_core.py, as required for forward pass(inference) through a pretrained model.
#				  Functions in this file usually map batched input to regular input for function in dnn_core module.
#   
# @Author       : Rahul Bhartari
# @Creation Date: 20th July 2018
#
import libdnn.dnn_core as dnnc

# matrix addition
#	@Parameters:
#		input_mtx1	: 4d matrix [batch:[arrays:[array]]]
#		input_mtx2	: 1-4d filter matrix with same first(higher) dimension
#
def matadd(input_mtx1, input_mtx2):
    output_v = []
    ln1, ln2 = 0, 0
    if hasattr(input_mtx1, '__iter__'):
        ln1 = len(input_mtx1)
    if hasattr(input_mtx2, '__iter__'):
        ln2 = len(input_mtx2)
    if ln1 != ln2 and ln1 != 0 and ln2 != 0:
        print("Error(matadd): Invalid dimension matrices !!")
        print("mx1, mtx2:",ln1, ln2)
        print("mtx1:", dnnc.__get_adjusted_mtx_dimensions(input_mtx1)[1])
        print("mtx2:", dnnc.__get_adjusted_mtx_dimensions(input_mtx2)[1])
        return input_mtx1
    # if single value
    if ln1 == 0 and ln2 == 0:
        return input_mtx1 + input_mtx2
    # recursive matrix addition endpoint
    if ln1!=0 and ln2==0:
        output_v = matadd(input_mtx1, [input_mtx2]*ln1)
    elif ln1==0 and ln2!=0:
        output_v = matadd([input_mtx1]*ln2, input_mtx2)
    else:
        # both matrices will be of same higher dimension, if control reaches here
        for i in range(ln1):
            output_v.append(matadd(input_mtx1[i], input_mtx2[i]))
    return output_v

# matrix multiplication(input_mtx1:3d input(2d x multi-input) input_mtx2:2d input, 3d output)
def matmul(input_mtx1, input_mtx2):
    output_v = []
    ln = len(input_mtx1)
    for i in range(ln):
        op = dnnc.mtx_mul(input_mtx1[i], input_mtx2)
        while len(op) == 1 and hasattr(op, '__iter__'):
            op = op[0]
        output_v.append(op)
    return output_v

#
#	@Parameters:
#		input_v	: 3d matrix [batch:[arrays:[array]]]
#		filter	: 1d filter matrix with dimension
#		stride	: number of positions by which to move the filter
#		padding	: 'valid' or 'same'
#

def conv1d(input_v, filter_mtx, stride, padding):
	output_v = []
	sp = False
	if padding == 'same':
		sp = True
	for channel in input_v:
		output_v.append(list())
		for arr in channel:
			output_v[-1].append(dnnc.conv_1d(arr, filter_mtx, stride, sp))
	return output_v


#
#	@Parameters:
#		input_v	: 4D matrix [batch:[image_channels:[h[ x w image]]]]
#		filter	: 4D filter matrix with dimension (o_c x i_c x h x w)
#		strides	: array with 2 elements, each denoting strides for each dimension of the input except channels and batch
#		padding	: 'valid' or 'same'
#

def conv2d(input_v, filter_mtx, strides, padding):
    output_v = []
    sp = False
    if padding == 'same':
        sp = True
    for inp_d in input_v:
        #print(dnnc.__get_adjusted_mtx_dimensions(inp_d))
        output_v.append(list())
        for filter_3d in filter_mtx:
            #print(dnnc.__get_adjusted_mtx_dimensions(filter_3d)[1])
            output_v[-1].append(dnnc.conv_2d(inp_d, filter_3d, strides, sp))
    return output_v

# dense layer(4d input, 2d output(+1 added dimension))
def flatten(input_v):
    output_v = []
    for ip3d in input_v:
        output_v.append([dnnc.flatten(ip3d)])
    return output_v

# average pooling
def avgpool_1d(input_v, kernel_size, stride, padding):
	sp = False
	if padding == 'same':
		sp = True
	return dnnc.avg_pool_1d(input_v, kernel_size, stride, sp)

#
#	@Parameters:
#		input_v		: 4D matrix [batch:[image_channels:[w x h image]]]
#		kernel_size	: size of the kernel
#		strides		: number of shifts for each pool
#		padding		: 'same' or 'valid'
#
def avgpool_2d(input_v, kernel_size, strides, padding):
	output_v = []
	sp = False
	if padding == 'same':
		sp = True
	for ip_3d in input_v:
		output_v.append(dnnc.avg_pool_2d(ip_3d, kernel_size, strides, sp))
	return output_v

# max pool
def maxpool_1d(input_v, kernel_size, stride, padding):
	sp = False
	if padding == 'same':
		sp = True
	return dnnc.max_pool_1d(input_v, kernel_size, stride, sp)

#
#	@Parameters:
#		input_v		: 4D matrix [batch:[image_channels:[w x h image]]]
#		kernel_size	: size of the kernel
#		strides		: number of shifts for each pool
#		padding		: 'same' or 'valid'
#
def maxpool_2d(input_v, kernel_size, strides, padding):
	output_v = []
	sp = False
	if padding == 'same':
		sp = True
	for ip_3d in input_v:
		output_v.append(dnnc.max_pool_2d(ip_3d, kernel_size, strides, sp))
	return output_v


# Activation functions

# Process in batches
def __call_activation(handle, input_v, alpha):
    output_v = []
    if alpha == 0:
        output_v = [handle(ip3d) for ip3d in input_v]
    else:
        output_v = [handle(ip3d, alpha) for ip3d in input_v]
    return output_v

def sigmoid(input_v):
	return __call_activation(dnnc.sigmoid, input_v, 0)

def softmax(input_v):
	return __call_activation(dnnc.softmax, input_v, 0)

def elu(input_v, alpha):
	return __call_activation(dnnc.elu, input_v, alpha)

def relu(input_v):
	return __call_activation(dnnc.relu, input_v, 0)

def leaky_relu(input_v, alpha):
	return __call_activation(dnnc.leaky_relu, input_v, alpha)


# print(elu([[[1,1,1],[2,2,2],[-1,0,1]],[[-4,-1,1],[-1,2,3],[0,2,1]]], 0.01))
# print(relu([[[1,1,1],[2,2,2],[-1,0,1]],[[-4,-1,1],[-1,2,3],[0,2,1]]]))
####-------- End Of File --------####
