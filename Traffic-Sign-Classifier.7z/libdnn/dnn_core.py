
#
# @Description	: This file contains implementation of neural network components required for
#		  		  forward pass(inference) through a pretrained model.
#	
# @Author		: Rahul Bhartari
# @Creation Date: 17th July 2018
#

import sys

'''
	Functions intended for internal use.
'''
# constants
__e = 2.718281828459045

#operation lambdas
def _sqr(x): return x * x
def _sqrt(x): return x ** 0.5
def _mul(x): return x[0] * x[1]
def _add(x): return x[0] + x[1]
def _div(x): return x[0] / x[1]
def _mod(x): return x[0] % x[1]
def _sigm(x): return round(1/(1 + (__e ** (-x))), 10)
def _softm(x): return round((__e ** x[0])/x[1], 10)
def _exp(x): return round(__e ** x, 10)

# vectorise and perform operations on input arrays
def vector_op(op, *operands):
	func = None
	if op == 'sqrt':
		func = _sqrt
	elif op == 'sqr':
		func = _sqr
	elif op == 'mul':
		func = _mul
	elif op == 'add':
		func = _add
	elif op == 'div':
		func = _div
	elif op == 'mod':
		func = _mod
	elif op == 'sigm':
		func = _sigm
	elif op == 'softm':
		func = _softm
	elif op == 'exp':
		func = _exp

	if len(operands) > 1:
		return list(map(func, list(zip(operands[0], operands[1]))))
	return list(map(func, operands[0]))

#print(vector_op('mul', [1,2,3], [0,2,4]))

#Error Code messages								Error Code
err_msg = ['Zero filter size',							# -1
	   		'Unequal filter side lengths',				# -2
	   		'Filter side length is even',				# -3
			'Matrices dimensions mismatch',				# -4
			'Unequal input channels',					# -5
			'Filter depth and input depth mismatch']	# -6

# Get error message for given error code
def get_error_msg(error_code):
	if error_code > -1:
		return False
	err_msg_indx = (-1*error_code)-1
	if err_msg_indx >= len(err_msg):
		print('error msg for error code:'+str(error_code)+'not found!!')
		return False
	return err_msg[err_msg_indx]

# get matrix dimentions
def __get_adjusted_mtx_dimensions(mtx):
	mtx_dm = None
	if hasattr(mtx, '__iter__'):
		if hasattr(mtx[0], '__iter__'):
			if hasattr(mtx[0][0], '__iter__'):
				mtx_dm = [len(mtx[0]), len(mtx[0][0]), len(mtx)]
			else:
				mtx_dm = [len(mtx), len(mtx[0]), 1]
				mtx = [mtx]
		else:
			mtx_dm = [1, len(mtx), 1]
			mtx = [[mtx]]
	else:
		mtx_dm = [0, 1, 0]
	return mtx, mtx_dm

# Test 2D convolution
def __print2d(mtx):
	for channel in mtx:
		for row in channel:
			print(row)
		print()

'''
	Functions intended to be used outside of this file.
'''

'''
	@Function	: Matrix addition
	@Parameters	:
		input_mtx1	: input 2d matrix with dimensions (m x n)
		input_mtx2	: input 2d matrix with dimensions (m x n)
'''
def mtx_add(input_mtx1, input_mtx2):
	error_code = 0
	# input dimention check
	input_mtx1, mtx1_dm = __get_adjusted_mtx_dimensions(input_mtx1)
	input_mtx2, mtx2_dm = __get_adjusted_mtx_dimensions(input_mtx2)
	
	for i in range(len(mtx1_dm)):
		if mtx1_dm[i] != mtx2_dm[i]:
			error_code = -4
			break
	if error_code < 0:
		print(get_error_msg(error_code))
		return [[[]]]
	
	# add the matrices
	#__print2d(input_mtx1)
	#__print2d(input_mtx2)
	output_mtx = []
	for ch in range(mtx1_dm[-1]):
		output_mtx.append(list())
		for hx in range(mtx1_dm[0]):
			output_mtx[ch].append(vector_op('add', input_mtx1[ch][hx], input_mtx2[ch][hx]))
	return output_mtx



'''
	@Function	: Matrix dot product
	@Parameters	:
		input_mtx1	: input 2d matrix with dimensions (m x n)
		input_mtx2	: input 2d matrix with dimensions (n x m)
'''
def mtx_mul(input_mtx1, input_mtx2):
	error_code = 0
	scalar_n = 0
	# input dimension check
	input_mtx1, mtx1_dm = __get_adjusted_mtx_dimensions(input_mtx1)
	input_mtx2, mtx2_dm = __get_adjusted_mtx_dimensions(input_mtx2)
	
	#scalar value check
	dm = [mtx1_dm, mtx2_dm]
	for i in range(2):
		if dm[i][0] == 0 and dm[i][1] == 1 and dm[i][2] == 0:
			scalar_n += i+1
	if scalar_n > 2:
		error_code = -4
	elif scalar_n == 0:
		if mtx1_dm[1] != mtx2_dm[0]:
			error_code = -4
		if mtx1_dm[-1] != mtx2_dm[-1]:
			error_code = -5
	if error_code < 0:
		print('Error(matmul):'+get_error_msg(error_code))
		print(dm)
		return [[]]
	
	# set mtx1 and mtx2
	mtx1, mtx2 = None, None
	scalar = None
	if scalar_n == 1:
		scalar = input_mtx1
		mtx1 = input_mtx2
	elif scalar_n == 2:
		scalar = input_mtx2
		mtx1 = input_mtx1
	else:
		mtx1 = input_mtx1
		mtx2 = input_mtx2
	#print('scalar:', scalar_n)
	#print('mtx1', len(mtx1), len(mtx1[0]), len(mtx1[0][0]))
	#print('mtx2', len(mtx2), len(mtx2[0]), len(mtx2[0][0]))
	#print(dm)
	# multiply matrices
	output_mtx = []
	if scalar_n > 0:	# scalar multiplication
		for ch in mtx1:
			output_mtx.append(list())
			chl = len(ch[0])
			for i in range(len(ch)):
				output_mtx[-1].append(vector_op('mul', [scalar]*chl, ch[i]))
	else:			# matrix multiplication
		for chx in range(mtx1_dm[-1]):
			ch1 = mtx1[chx]
			ch2 = mtx2[chx]
			output_mtx.append(list())
			for hx in range(mtx1_dm[0]):
				output_mtx[chx].append(list())
				vec1 = ch1[hx]
				for wx in range(mtx2_dm[1]):
					vec2 = [v[wx] for v in ch2]
					output_mtx[chx][-1].append(sum(vector_op('mul', vec1, vec2)))
	
	return output_mtx



'''
	@Function	: 1-dimensional convolution filter
	@Parameters	:
		input_mtx	: 1-2d input array
		filter_mtx	: 1d filter of dimensions
		stride		: number of cells to move
		same_padding: true/false, if true pad with zeroes, size of output is same as input, default false
'''
def conv_1d(input_mtx, filter_mtx, stride=1, same_padding=False):
	error_code = 0
	# input dimension check
	ip_dim = []
	is_iter = hasattr(input_mtx[0], '__iter__')
	if is_iter:
		ip_dim = [len(input_mtx), len(input_mtx[0])]
	else:
		ip_dim = [0, len(input_mtx)]

	#performing input checks
	fl_ln = len(filter_mtx)
	if fl_ln == 0:			# zero filter width
		error_code = -1
	if fl_ln%2 == 0:		# even filter width
		error_code = -3
	if error_code < 0:		# get error
		print(get_error_msg(error_code))
		return False
	
	# Perform convolution
	output_mtx = []
	# padding
	lpad_n = 0
	if same_padding:
		lpad_n = (fl_ln//2)
		if is_iter:
			for i in range(ip_dim[0]):
				input_mtx[i] = [0]*lpad_n + input_mtx[i] + [0]*lpad_n
		else:
			input_mtx = [0]*lpad_n + input_mtx + [0]*lpad_n
	
	# convolve
	filter_mtx = filter_mtx[::-1]
	if is_iter:
		nw = len(input_mtx[0])
		for h in range(ip_dim[0]):
			output_mtx.append(list())
			for i in range(0, nw, stride):
				if nw-i < fl_ln:
					break
				output_mtx[h].append(sum(vector_op('mul', input_mtx[h][i:i+fl_ln], filter_mtx)))
	else:
		nw = len(input_mtx)
		for i in range(0, nw, stride):
			if nw-i < fl_ln:
				break
			output_mtx.append(sum(vector_op('mul', input_mtx[i:i+fl_ln], filter_mtx)))
		output_mtx = [output_mtx]
	return output_mtx


'''
	@Function	: 2-dimensional convolution filter
	@Parameters	:
		input_mtx	: 2-3 dimensional matrix
		filter_mtx	: 3-dimensional filter of dimensions[c, h, w]
		strides		: a tuple containing number of cells to move[h, w]
		same_padding: true/false, if true pad with zeroes, size of output is same as input, default false
'''
def conv_2d(input_mtx, filter_mtx, strides=(1,1), same_padding=False):
	error_code = 0
	# get dimensions of input matrix
	w, h, ch = len(input_mtx[0]), len(input_mtx), 1
	is_iter = hasattr(input_mtx[0][0], '__iter__')
	if is_iter:
		w, h, ch = len(input_mtx[0][0]), len(input_mtx[0]), len(input_mtx)
	else:
		input_mtx = [input_mtx]
	#performing input checks
	flh, flw = len(filter_mtx[0]), len(filter_mtx[0][0])
	if flw == 0 or flh == 0:	# zero filter dimension
		error_code = -1
	if flw != flh:				# unequal filter dimensions
		errir_code = -2
	if flw%2 == 0 or flh%2 == 0:	# even filter dimension
		error_code = -3
	if ch != len(filter_mtx):		# filter depth mismatch with input depth (no. of channels)
		error_code = -6
	if error_code < 0:			# get error
		print('conv_2d:'+get_error_msg(error_code))
		print("ch, h, w:", ch, h, w)
		print("filter h, w:", flh, flw)
		return False
	#__print2d(input_mtx)
	# pad input matrix
	pad_ln = 0
	if same_padding:
		pad_ln = flw//2
		for ip_ch in range(ch):
			for i in range(pad_ln):
				input_mtx[ip_ch].insert(0, [0]*w)
				input_mtx[ip_ch].append([0]*w)
			for hx in range(h+flw-1):
				input_mtx[ip_ch][hx] = [0]*pad_ln + input_mtx[ip_ch][hx] + [0]*pad_ln
	#print(input_mtx)
	# Perform convolution
	# invert filter
	for i in range(ch):
		filter_mtx[i] = filter_mtx[i][::-1]
		filter_mtx[i] = [_mtx[::-1] for _mtx in filter_mtx[i]]
	# vectorise the filter
	filter_vec = [list()]*ch
	for i in range(ch):
		for j in range(flh):
			filter_vec[i] = filter_vec[i] + filter_mtx[i][j]
	output_mtx = []
	#print('h:', h, 'w:', w, 'ch:', ch) 
	nh = h + 2*pad_ln
	nw = w + 2*pad_ln
	# for each channel
	for cx in range(ch):
		output_mtx.append(list())
		for hx in range(0, nh, strides[0]):
			if nh-hx < flw:
				break
			output_mtx[cx].append(list())
			for wx in range(0, nw, strides[1]):
				if nw-wx < flw:
					break
				ip_vec = []
				for i in range(flh):
					#print(input_mtx[cx][hx+i][wx:wx+flw])
					ip_vec = ip_vec + input_mtx[cx][hx+i][wx:wx+flw]
				output_mtx[cx][-1].append(sum(vector_op('mul', ip_vec, filter_vec[cx])))
	for cx in range(1, ch):
		for hx in range(len(output_mtx[0])):
			for wx in range(len(output_mtx[0][0])):
				output_mtx[0][hx][wx] += output_mtx[cx][hx][wx]
	output_mtx = output_mtx[0]
	return output_mtx


'''
	@Function	: 3-dimensional convolution filter
	@Parameters	:
		input_mtx		: 3-dimensional matrix
		filter_mtx		: filter of dimensions[w, h, d]
		same_padding	: true/false, if true pad with zeroes, size of output is same as input, default false
'''
def conv_3d(input_mtx, filter_mtx, same_padding=False):
	# postponed to be done at last
	return [[[[]]]]


'''
	@Function	: flatten the input along with the input channels
	@Parameters	:
		input_mtx	: 3-dimensional matrix(2-d matrix with n channels)
'''
def flatten(input_mtx):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	if mtx_dm[:] == [0,1,0]:
		return [input_mtx]
	# flatten the matrices
	#print("flatten:", mtx_dm)
	output_mtx = []
	for hx in range(mtx_dm[0]):
		for wx in range(mtx_dm[1]):
			for cx in range(mtx_dm[2]):
				output_mtx.append(input_mtx[cx][hx][wx])
	#for ch in input_mtx:
	#	for row in ch:
	#		output_mtx += row
	return output_mtx


'''
	@Function	: dropout
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix(weights)
		keep_prob	: keep probability
'''
def dropout(input_mtx, keep_prob):
	# If weights already set to 0 while training, then this function is not required
	pass



'''
	Pooling layers
'''

# internal operation for both max and average pooling
def __pool_1d(input_mtx, operation, filter_size, stride, same_padding):
	mtx_dm = [1, 1]
	# check dimensions
	if hasattr(input_mtx, '__iter__'):
		if hasattr(input_mtx[0], '__iter__'):
			mtx_dm = [len(input_mtx), len(input_mtx[0])]
		else:
			mtx_dm = [1, len(input_mtx)]
			input_mtx = [input_mtx]
	else:
		return [[input_mtx]]
	
	# padding
	pad_ln = 0
	if same_padding:
		pad_ln = filter_size//2
		for chx in range(mtx_dm[0]):
			input_mtx[chx] =[0]*pad_ln +  input_mtx[chx] + [0]*pad_ln
	#print(input_mtx)
	# 1d pooling
	output_mtx = []
	for ch in input_mtx:
		output_mtx.append(list())
		# output width = 1 + (W + 2*P -F)/S
		for i in range(0, mtx_dm[1] + 2*pad_ln, stride):
			arr = ch[i:i+filter_size]
			if len(arr) < filter_size:
				continue
			if operation == 'max':
				output_mtx[-1].append(max(arr))
			if operation == 'avg':
				output_mtx[-1].append(round(sum(arr)/filter_size, 10))
	return output_mtx


def __pool_2d(input_mtx, operation, filter_size, strides, same_padding):
	# dimensions check
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	if mtx_dm[:] == [0,1,0]:
		return input_mtx
	if strides[0] < 1 or strides[1] < 1:
		strides = (1, 1)
	if filter_size < 2:
		filter_size = 2

	# padding
	pad_ln = 0
	need_dim_padding = not ((mtx_dm[0]%filter_size) == 0) and ((mtx_dm[1]%filter_size) == 0)
	if same_padding and need_dim_padding:
		pad_ln = filter_size//2
		for ip_ch in range(mtx_dm[2]):
			for i in range(pad_ln):
				input_mtx[ip_ch].insert(0, [0]*mtx_dm[1])
				input_mtx[ip_ch].append([0]*mtx_dm[1])
			for hx in range(mtx_dm[0]+(2*pad_ln)):
				input_mtx[ip_ch][hx] = [0]*pad_ln + input_mtx[ip_ch][hx] + [0]*pad_ln
	#print(mtx_dm)
	# pooling
	output_mtx = []
	nh = mtx_dm[0] + 2*pad_ln
	nw = mtx_dm[1] + 2*pad_ln
	fct = filter_size * filter_size
	tmp_a = None
	for ch in input_mtx:
		output_mtx.append(list())
		for hx in range(0, nh, strides[0]):
			if nh-hx < filter_size:
				break
			output_mtx[-1].append(list())
			for wx in range(0, nw, strides[1]):
				if nw-wx < filter_size:
					break
				tmp_a = 0
				for i in range(filter_size):
					arr = ch[hx+i][wx:wx+filter_size]
					#print(arr)
					if operation == 'max':
						tmp_a = max(arr)
					elif operation == 'avg':
						tmp_a += sum(arr)
				if operation == 'avg':
					tmp_a /= fct
				output_mtx[-1][-1].append(round(tmp_a, 10))
	return output_mtx



'''
	@Function	: 1D max pooling
	@Parameters	:
		input_mtx	: 1-2 dimensional matrix
		filter_size	: size of the filter for pooling
		strides		: number of cells to move at a time
		same_padding: True if same padding, else valid padding
'''
def max_pool_1d(input_mtx, filter_size=2, stride=1, same_padding=False):
	return __pool_1d(input_mtx, 'max', filter_size, stride, same_padding)


'''
	@Function	: 1D average pooling
	@Parameters	:
		input_mtx	: 1-2 dimensional matrix
		filter_size	: size of the filter for pooling
		strides		: number of cells to move at a time
		same_padding: True if same padding, else valid padding
'''
def avg_pool_1d(input_mtx, filter_size=2, stride=1, same_padding=False):
	return __pool_1d(input_mtx, 'avg', filter_size, stride, same_padding)



'''
	@Function	: dropout
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix
		filter_size	: size of the filter for pooling
		strides		: number of cells to move at a time
		same_padding: True if same padding, else valid padding
'''
def max_pool_2d(input_mtx, filter_size=2, strides=(1,1), same_padding=False):
	return __pool_2d(input_mtx, 'max', filter_size, strides, same_padding)


'''
	@Function	: dropout
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix
		filter_size	: size of the filter for pooling
		strides		: number of cells to move at a time
		same_padding: True if same padding, else valid padding
'''
def avg_pool_2d(input_mtx, filter_size=2, strides=(1,1), same_padding=False):
	return __pool_2d(input_mtx, 'avg', filter_size, strides, same_padding)



'''
	Activation Functions
'''

'''
	@Function	: softmax activation
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix with dimensions[h, w, c]
'''
def sigmoid(input_mtx):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	
	# if single value
	if mtx_dm[0] == 0 and mtx_dm[2] == 0:
		return [[[_sigm(input_mtx)]]]

	# calculate sigmoid
	output_mtx = []
	for ch in input_mtx:
		output_mtx.append(list())
		for i in range(mtx_dm[0]):
			output_mtx[-1].append(vector_op('sigm', ch[i]))
	return output_mtx



'''
	@Function	: softmax activation
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix with dimensions[h, w, c]
'''
def softmax(input_mtx):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	
	# if single value
	if mtx_dm[0] == 0 and mtx_dm[2] == 0:
		return [[[1.0]]]
	
	# calculate softmax
	output_mtx = []
	exp_sm = 0.0
	mx_v = 0.0
	# get max value in input_mtx
	for ch in input_mtx:
		for row in ch:
			m = max(row)
			if m > mx_v:
				mx_v = m

	mxv_l = [1/mx_v]*mtx_dm[1]
	# get all exponential values in all channels
	for ch in input_mtx:
		output_mtx.append(list())
		for i in range(mtx_dm[0]):
			tmp_l = vector_op('exp', vector_op('mul', ch[i], mxv_l))
			exp_sm += sum(tmp_l)
			output_mtx[-1].append(tmp_l)
	exp_sm_l = [exp_sm]*mtx_dm[1]
	#__print2d(output_mtx)

	# replace exponential values in otput_mtx with softmax values
	for chx in range(mtx_dm[-1]):
		for hx in range(mtx_dm[0]):
			output_mtx[chx][hx] = vector_op('softm', output_mtx[chx][hx], exp_sm_l)
	
	return output_mtx



'''
	@Function	: ELU activation
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix with dimensions[h, w, c]
		alpha		: constant multiplier
'''
def elu(input_mtx, alpha):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	
	# if single value
	if mtx_dm[0] == 0 and mtx_dm[2] == 0:
		if input_mtx < 0:
			return [[[round(alpha*(_exp(input_mtx) - 1), 10)]]]
		return input_mtx
	
	# calculate activation
	output_mtx = []
	for ch in input_mtx:
		output_mtx.append(list())
		for row in ch:
			output_mtx[-1].append(list())
			for el in row:
				v = el
				if el < 0:
					v = round(alpha*(_exp(el) - 1), 10)
				output_mtx[-1][-1].append(v)
	return output_mtx



'''
	@Function	: Leaky RELU activation
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix with dimensions[h, w, c]
		alpha		: constant multiplier
'''
def leaky_relu(input_mtx, alpha):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	
	# if single value
	if mtx_dm[0] == 0 and mtx_dm[2] == 0:
		v = input_mtx
		if v < 0:
			v = alpha*v
		return [[[v]]]
	
	# calculate activation
	output_mtx = []
	for ch in input_mtx:
		output_mtx.append(list())
		for row in ch:
			output_mtx[-1].append(list())
			for el in row:
				v = el
				if el < 0:
					v = round(alpha*el, 10)
				output_mtx[-1][-1].append(v)
	
	return output_mtx



'''
	@Function	: RELU activation
	@Parameters	:
		input_mtx	: 1-3 dimensional matrix with dimensions[h, w, c]
'''
def relu(input_mtx):
	# check dimensions
	input_mtx, mtx_dm = __get_adjusted_mtx_dimensions(input_mtx)
	
	# if single value
	if mtx_dm[0] == 0 and mtx_dm[2] == 0:
		return [[[max(input_mtx, 0)]]]
	
	# calculate activation
	output_mtx = []
	for ch in input_mtx:
		output_mtx.append(list())
		for row in ch:
			output_mtx[-1].append(list())
			for el in row:
				output_mtx[-1][-1].append(max(el, 0))
	return output_mtx



### ---------- End Of File ---------- ###

